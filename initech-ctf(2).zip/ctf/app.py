"""Beginner CTF: "Key Handout" -- certificate-based sign-in.

Run:  pip install flask cryptography
      FLAG='CTF{...}' python app.py      (then open http://localhost:5000)

On first run, ./data is generated: a company CA, employee certificates,
and the leaked email containing John's private key.
"""
import base64
import datetime as dt
import html
import os
import secrets
import time
from pathlib import Path

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
from flask import Flask, jsonify, request, send_from_directory

FLAG = os.environ.get("FLAG", "CTF{n3v3r_em41l_y0ur_pr1v4t3_k3y}")
DATA = Path(__file__).parent / "data"
STATIC = Path(__file__).parent / "static"
CHALLENGE_TTL = 300  # seconds

EMPLOYEES = [
    ("Priya", "Shah", "Finance"),
    ("John", "Miller", "Engineering"),
    ("Maria", "Gonzalez", "Human Resources"),
    ("Kevin", "Okafor", "Sales"),
    ("Hannah", "Lee", "Engineering"),
    ("Daniel", "Brooks", "Corporate IT"),
]

app = Flask(__name__, static_folder=None)
challenges = {}  # token -> (challenge, cert_fingerprint, expires_at)


# ---------------------------------------------------------------- setup
def _name(**parts):
    oids = {"C": NameOID.COUNTRY_NAME, "O": NameOID.ORGANIZATION_NAME,
            "OU": NameOID.ORGANIZATIONAL_UNIT_NAME, "CN": NameOID.COMMON_NAME}
    return x509.Name([x509.NameAttribute(oids[k], v) for k, v in parts.items()])


def generate_data():
    DATA.mkdir(exist_ok=True)
    now = dt.datetime.now(dt.timezone.utc)
    ca_key = ec.generate_private_key(ec.SECP256R1())
    ca_name = _name(C="US", O="Initech Corp", CN="Initech Corp Issuing CA 01")
    ca_cert = (x509.CertificateBuilder()
               .subject_name(ca_name).issuer_name(ca_name)
               .public_key(ca_key.public_key())
               .serial_number(x509.random_serial_number())
               .not_valid_before(now - dt.timedelta(days=1))
               .not_valid_after(now + dt.timedelta(days=3650))
               .add_extension(x509.BasicConstraints(ca=True, path_length=0), True)
               .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), False)
               .sign(ca_key, hashes.SHA256()))
    (DATA / "ca.pem").write_bytes(ca_cert.public_bytes(serialization.Encoding.PEM))

    directory = []
    for first, last, dept in EMPLOYEES:
        key = ec.generate_private_key(ec.SECP256R1())
        user = f"{first[0]}{last}".lower()
        cert = (x509.CertificateBuilder()
                .subject_name(_name(C="US", O="Initech Corp", OU=dept, CN=f"{first} {last}"))
                .issuer_name(ca_name)
                .public_key(key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now - dt.timedelta(days=1))
                .not_valid_after(now + dt.timedelta(days=365))
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), True)
                .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), False)
                .add_extension(x509.SubjectAlternativeName(
                    [x509.RFC822Name(f"{user}@initech.example")]), False)
                .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), False)
                .sign(ca_key, hashes.SHA256()))
        pem = cert.public_bytes(serialization.Encoding.PEM).decode()
        directory.append((first, last, dept, f"{user}@initech.example", pem))
        if first == "John":
            john_key = key.private_bytes(serialization.Encoding.PEM,
                                         serialization.PrivateFormat.PKCS8,
                                         serialization.NoEncryption()).decode()
    # CA private key is intentionally discarded: nobody can mint new certs.

    rows = "\n".join(
        f"<tr><td>{html.escape(f)}</td><td>{html.escape(l)}</td><td>{html.escape(d)}</td>"
        f"<td>{html.escape(e)}</td><td><details><summary>Show certificate</summary>"
        f"<pre>{html.escape(p)}</pre></details></td></tr>"
        for f, l, d, e, p in directory)
    (DATA / "directory.html").write_text(PAGE.format(title="Employee Directory", body=f"""
<h1>Initech Corp &middot; Employee Directory</h1>
<p>Public sign-in certificates for all staff. Certificates are public &mdash; sharing them is safe.</p>
<table><tr><th>First</th><th>Last</th><th>Department</th><th>Email</th><th>Certificate</th></tr>
{rows}</table>"""))

    (DATA / "email.html").write_text(PAGE.format(title="Leaked email", body=f"""
<h1>Leaked email</h1>
<div class="mail">
<b>From:</b> Daniel Brooks &lt;dbrooks@initech.example&gt;<br>
<b>To:</b> John Miller &lt;jmiller@initech.example&gt;<br>
<b>Subject:</b> your sign-in key<br><hr>
<p>Hey John,</p>
<p>Your smart card still hasn't shipped, so here's the key file for your account in the
meantime. Just save it as <code>john.key</code> and you're good to go.</p>
<pre>{john_key}</pre>
<p>Please don't forward this to anyone.<br>&mdash; Daniel, Corporate IT</p>
</div>"""))


# ---------------------------------------------------------------- pages
PAGE = """<!DOCTYPE html><html><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:960px;margin:2rem auto;padding:0 1rem;color:#222}}
pre{{background:#f4f4f4;padding:.6rem;overflow-x:auto;font-size:12px}}
table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccc;padding:.4rem;vertical-align:top;text-align:left}}
.mail{{border:1px solid #ccc;padding:1rem;border-radius:6px}}</style></head><body>
<p><a href="/">Sign in</a> &middot; <a href="/directory">Directory</a> &middot; <a href="/email">Leaked email</a></p>
{body}</body></html>"""


@app.get("/")
def index():
    return send_from_directory(STATIC, "index.html")


@app.get("/signer")
def signer():
    return send_from_directory(STATIC, "signer.html")


@app.get("/directory")
def directory():
    return send_from_directory(DATA, "directory.html")


@app.get("/email")
def email():
    return send_from_directory(DATA, "email.html")


# ---------------------------------------------------------------- sign-in API
def load_ca():
    return x509.load_pem_x509_certificate((DATA / "ca.pem").read_bytes())


@app.post("/api/certificate")
def submit_certificate():
    log = []
    pem = (request.json or {}).get("certificate", "").strip()
    try:
        cert = x509.load_pem_x509_certificate(pem.encode())
    except Exception:
        return jsonify(ok=False, log=["I couldn't parse that. Paste the full PEM, "
                                      "including the -----BEGIN CERTIFICATE----- line."])
    name = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    name = name[0].value if name else "(no name)"
    log.append(f"Received a certificate claiming to belong to: {name}.")
    log.append("Anyone can send me a certificate &mdash; they're public. First I check it's genuine.")

    ca = load_ca()
    log.append(f"Issuer: {cert.issuer.rfc4514_string()}. Do I trust that CA?")
    if cert.issuer != ca.subject:
        log.append("No. This wasn't issued by Initech's CA. Rejected.")
        return jsonify(ok=False, log=log)
    try:
        ca.public_key().verify(cert.signature, cert.tbs_certificate_bytes,
                               ec.ECDSA(cert.signature_hash_algorithm))
    except InvalidSignature:
        log.append("I hashed the certificate body and checked the CA's signature with the "
                   "CA's public key. It does NOT match &mdash; this certificate was forged or edited. Rejected.")
        return jsonify(ok=False, log=log)
    log.append("Yes. I hashed the certificate body (SHA-256) and checked the CA's signature on it "
               "using the CA's public key. It matches, so Initech's CA really issued this and nothing was changed.")

    now = dt.datetime.now(dt.timezone.utc)
    if not (cert.not_valid_before_utc <= now <= cert.not_valid_after_utc):
        log.append("But it's expired or not yet valid. Rejected.")
        return jsonify(ok=False, log=log)
    log.append(f"It's within its validity period (until {cert.not_valid_after_utc:%Y-%m-%d}).")
    try:
        eku = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
        assert ExtendedKeyUsageOID.CLIENT_AUTH in eku
    except Exception:
        log.append("It isn't marked for client authentication. Rejected.")
        return jsonify(ok=False, log=log)
    log.append("Its Extended Key Usage says 'Client Authentication', so it may be used to sign in.")

    pub = cert.public_key().public_bytes(serialization.Encoding.X962,
                                         serialization.PublicFormat.UncompressedPoint).hex()
    log.append(f"So: Initech vouches that the P-256 public key {pub[:16]}…{pub[-8:]} belongs to {name}.")
    log.append("But this certificate is public &mdash; anyone could have copied it. "
               "Now I need to verify it belongs to <b>you</b>.")

    challenge = f"initech-login:{secrets.token_hex(16)}"
    token = secrets.token_urlsafe(16)
    fp = cert.fingerprint(hashes.SHA256())
    challenges[token] = (challenge, fp, time.time() + CHALLENGE_TTL)
    log.append("Sign the challenge below with your private key, and I'll verify the signature "
               "using the public key in your certificate. Only the real private key can produce "
               "a signature that matches.")
    return jsonify(ok=True, log=log, token=token, challenge=challenge, name=name,
                   pem=pem)


def parse_signature(text):
    text = "".join(text.split())
    if ")=" in text:  # tolerate "SHA2-256(stdin)= <hex>" from openssl -hex
        text = text.split(")=")[-1]
    try:
        raw = bytes.fromhex(text)
    except ValueError:  # not hex -> try base64 / base64url
        raw = base64.b64decode(text.replace("-", "+").replace("_", "/") + "==", validate=False)
    if len(raw) == 64:  # raw r||s
        return encode_dss_signature(int.from_bytes(raw[:32], "big"),
                                    int.from_bytes(raw[32:], "big"))
    return raw  # assume DER


@app.post("/api/signature")
def submit_signature():
    body = request.json or {}
    entry = challenges.pop(body.get("token", ""), None)
    pem = body.get("certificate", "")
    if not entry or time.time() > entry[2]:
        return jsonify(ok=False, log=["That challenge expired or was already used. "
                                      "Submit your certificate again for a fresh one."])
    challenge, fp, _ = entry
    cert = x509.load_pem_x509_certificate(pem.encode())
    if cert.fingerprint(hashes.SHA256()) != fp:
        return jsonify(ok=False, log=["That's not the certificate this challenge was issued for."])
    log = [f"I computed SHA-256 of the challenge text: \"{challenge}\"."]
    try:
        sig = parse_signature(body.get("signature", ""))
        cert.public_key().verify(sig, challenge.encode(), ec.ECDSA(hashes.SHA256()))
    except (ValueError, InvalidSignature):
        log.append("Then I checked your signature against that hash using the public key from "
                   "the certificate. It does NOT match. Either it was signed with a different key, "
                   "or the challenge/format was wrong. Access denied.")
        return jsonify(ok=False, log=log)
    log.append("Then I checked your signature against that hash using the public key from the "
               "certificate. It matches! Only the holder of the matching private key could have "
               "made it.")
    name = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)[0].value
    log.append(f"Welcome, {name}.")
    if name == "John Miller":
        log.append(f"Here's your flag: <b>{FLAG}</b>")
    return jsonify(ok=True, log=log)


if __name__ == "__main__":
    if not (DATA / "ca.pem").exists():
        generate_data()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
